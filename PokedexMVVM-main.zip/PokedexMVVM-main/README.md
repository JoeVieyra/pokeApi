# PokedexMVVM
Made with SwiftUI

<img width="1360" alt="image" src="https://github.com/marcoalonso/PokedexMVVM/assets/49013250/671823d6-ed74-4127-b264-f193fcd9f4ee">

Filtrando pokemon con searchbar 


<img width="394" alt="image" src="https://github.com/marcoalonso/PokedexMVVM/assets/49013250/66a85295-52bd-46c5-829b-a1e6e6cec9e7">

