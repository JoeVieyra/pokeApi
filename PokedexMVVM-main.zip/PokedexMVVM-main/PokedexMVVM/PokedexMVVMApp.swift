//
//  PokedexMVVMApp.swift
//  PokedexMVVM
//
//  Created by Marco Alonso Rodriguez on 13/06/23.
//

import SwiftUI

@main
struct PokedexMVVMApp: App {
    var body: some Scene {
        WindowGroup {
            PokedexListView()
        }
    }
}
